// import Redux1 from "./components/Redux1"
import React from 'react';
import './App.css';
import CackeContainer from './components/CackeContainer';
import store from './redux/Store';
import { Provider } from 'react-redux';
import IceCreamContainer from './components/IceCreamContainer';
import NewCackeContainer from './components/NewCakeContainer';
import Useparam from './components/Useparam';
function App() {
  return (
    <Provider store = {store}>
      <div className="App">
        {/* <CackeContainer />
        <IceCreamContainer/>
        <NewCackeContainer/> */}
        <Useparam/>
      </div>
    </Provider>
  );
}

export default App;
