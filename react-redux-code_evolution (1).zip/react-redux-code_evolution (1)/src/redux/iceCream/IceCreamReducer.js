import { BUY_ICE_CREAM, SELL_ICE_CREAM } from "./IceCreamType";

const initialState ={
    numberOfIceCreams : 100
}

const iceCreamReducer = (state = initialState, action) =>{
    switch(action.type){
        case BUY_ICE_CREAM:return{
            ...state,
            numberOfIceCreams : state.numberOfIceCreams - 1
        }
        case SELL_ICE_CREAM: return{
            ...state,
            numberOfIceCreams: state.numberOfIceCreams + 1
        }
        default:return state
    }
}
export default iceCreamReducer;