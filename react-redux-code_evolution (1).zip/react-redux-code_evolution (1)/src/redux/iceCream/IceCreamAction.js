import { BUY_ICE_CREAM, SELL_ICE_CREAM } from "./IceCreamType";

export const buyIceCream = () => {
    return {
        type: BUY_ICE_CREAM
    }
}
export const sellIceCream = () => {
    return {
        type: SELL_ICE_CREAM
    }
}