import { createStore } from "redux";
import { combineReducers,applyMiddleware } from "redux";
import { composeWithDevTools } from "redux-devtools-extension";
import logger from "redux-logger";
import CakeReducer from "./cake/CakeReducer";
import iceCreamReducer from "./iceCream/IceCreamReducer";
const rootReducer = combineReducers({
    cake: CakeReducer,
    iceCream: iceCreamReducer
})
const store = createStore(rootReducer,composeWithDevTools( applyMiddleware(logger)))

export default store;