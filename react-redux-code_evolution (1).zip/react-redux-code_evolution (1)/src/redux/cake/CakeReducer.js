import { BUY_CAKE,SELL_CAKE} from './CakeTypes';

const initialState = {
    numberOfCakes: 10,
    // numberOfIceCreams: 20
}

const CakeReducer = (state=initialState, action) => {
    switch(action.type){
        case BUY_CAKE: return{
            ...state,
            numberOfCakes : state.numberOfCakes-action.payload
        }
        case SELL_CAKE: 
        console.log(typeof(Number(action.payload)))
        return{
            ...state,
            numberOfCakes: state.numberOfCakes + Number(action.payload)
        }
        // case BUY_ICE_CREAM: return{
        //     ...state,
        //     numberOfIceCreams: state.numberOfIceCreams -1
        // }
        // case SELL_ICE_CREAM: return{
        //     ...state,
        //     numberOfIceCreams: state.numberOfIceCreams +1
        // }
        default:return state
    }
}
export default CakeReducer