import { BUY_CAKE,SELL_CAKE } from './CakeTypes';

export const buyCake = (number = 1) => {
    console.log(number)
    return {
        type: BUY_CAKE,
        payload:number

    }
}
export const sellCake =(sellCakeQuantity = 1)=>{
    console.log(sellCakeQuantity)

    return{
        type: SELL_CAKE,
        payload: sellCakeQuantity
    }
}
// export const buyIceCream = ()=>{
//     return{
//         type: BUY_ICE_CREAM
//     }
// }
// export const SellIceCream = ()=>{
//     return{
//         type: SELL_ICE_CREAM
//     }
// } 