export const BUY_CAKE = "BUT_CAKE"
export const SELL_CAKE = "SELL_CAKE"
// export const BUY_ICE_CREAM = "BUY_ICE_CREAM"
// export const SELL_ICE_CREAM = "SELL_ICE_CREAM" 
