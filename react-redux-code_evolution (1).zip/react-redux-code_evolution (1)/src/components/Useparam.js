import React from 'react'

const Useparam = () => {
  return (
    <div>Useparam</div>
  )
}

export default Useparam