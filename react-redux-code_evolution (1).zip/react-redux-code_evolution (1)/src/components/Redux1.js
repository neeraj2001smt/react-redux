const redux = require('redux');
const createStore = redux.createStore

// creat a action
const BUY_CAKE = 'BUY_CAKE'
const BUY_ICECREAM = 'BUY_ICECREAM'

function buyCake() {
    return {
        type: BUY_CAKE,
        info: "this is cake action"
    }
} 
function buyIcecream() {
    return {
        type: BUY_ICECREAM,
        info: "this is icecream action"
    }
} 
// initial State
const initialstate = {
    number_of_cakes : 20,
    number_of_icecream : 30
}
// Create reducer 
const reducer= (state = initialstate, action)=>{
    switch (action.type){
        case BUY_CAKE : return{
            ...state,
            number_of_cakes : number_of_cakes -1
        }
        default:return{
            state
        }
    }
}

// Create Store
 const store = createStore(reducer);
 console.log("initial State",store.getstate())
 const unsubscribe = store.subscribe(()=> console.log("update State",store.getstate()))
 store.dispatch(buyCake())
 store.dispatch(buyCake())
 store.dispatch(buyCake())
 unsubscribe()

