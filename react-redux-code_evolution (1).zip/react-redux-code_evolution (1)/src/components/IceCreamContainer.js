import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { buyIceCream, sellIceCream } from '../redux'
const IceCreamContainer = () => {
    const numberOfIceCreams = useSelector(state => state.iceCream.numberOfIceCreams)
    const dispatch = useDispatch()
    console.log(numberOfIceCreams)
    return (
        <React.Fragment>
            <h1> this is From IcCream Container</h1>
            <h1> No of iceCream {numberOfIceCreams}: </h1>
            <button onClick={()=> dispatch(buyIceCream())}> buy Cake</button>
            <button onClick={()=> dispatch(sellIceCream())}> sale Cake</button>
        </React.Fragment>
    )
}

export default IceCreamContainer