import React, { useState } from 'react'
import { buyCake,sellCake } from '../redux'
import { connect } from 'react-redux'

const NewCackeContainer = (props) => {
    const [number,setNumber] = useState(1);
    const [sellCakeQuantity, setSellCakeQuantity] = useState(1)
    // const numberOfCakeName = useSelector(state => state.cake.numberOfCakes);

    // const dispatch = useDispatch()
    return (
        <React.Fragment>
            <h1> Number Of Cakes{props.numberOfCakeName } </h1>
            <input type='number' value={number} onChange={event=>setNumber(event.target.value)}/>
            <button onClick={()=>props.buyCakeName(number)}> buy {number} Cake</button>
            <br/>
            <br/>

            <input type="number" vlaue={sellCakeQuantity} onChange={event=> setSellCakeQuantity(event.target.value)} />
            <button onClick={()=>props.sellCakeName(sellCakeQuantity)}> Sell {sellCakeQuantity} Cake</button>
            <br/>
        </React.Fragment>
    )
}
const mapStateToProps = state => {
    return {
        numberOfCakeName: state.cake.numberOfCakes
    }
}
const mapDispatchToProps = dispatch  => {
    return {
        buyCakeName: number =>dispatch(buyCake(number)),
        sellCakeName: sellCakeQuantity=>dispatch(sellCake(sellCakeQuantity))

    }

}
export default connect(mapStateToProps, mapDispatchToProps)(NewCackeContainer)
// export default NewCackeContainer;/