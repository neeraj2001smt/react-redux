import React from 'react'
// import { connect } from 'react-redux'
import { useSelector,useDispatch } from 'react-redux'
import { buyCake, sellCake} from '../redux'

const CackeContainer = (props) => {
    const numberOfCakeName = useSelector(state => state.cake.numberOfCakes);
    // const numberOfIceCreamName = useSelector(state => state.numberOfIceCreams);

    const dispatch = useDispatch()
    return (
        <React.Fragment>
            <h1> Number Of Cakes{numberOfCakeName } </h1>
            <button onClick={()=> dispatch(buyCake())}> buy Cake</button>
            <button onClick={()=> dispatch(sellCake())}> sale Cake</button>
            <br/>
            {/* <h1> Number Of icecreacm{numberOfIceCreamName } </h1>
            <button onClick={()=> dispatch(buyIceCream())}> buy Cake</button>
            <button onClick={()=> dispatch(sellIceCream())}> sale Cake</button> */}
        </React.Fragment>
    )
}
// const mapStateToProps = state => {
//     return {
//         abc : "neeraj",
//         numberOfCakeName: state.numberOfCakes
//     }
// }
// const mapDispatchToProps = dispatch  => {
//     return {
//         buyCakeName: ()=>dispatch(buyCake()),
//         sellCakeName: ()=>dispatch(sellCake())
//     }
// }
// export default connect(mapStateToProps, mapDispatchToProps)(CackeContainer)
export default CackeContainer;